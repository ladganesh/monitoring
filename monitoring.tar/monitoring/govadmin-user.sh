#!/bin/bash
for user in govadmin
do
/usr/sbin/useradd $user
mkdir /home/$user/.ssh/
cd /home/$user/.ssh/
echo "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDAPpRRtX1/hQ+egivsqS8gs1ev+CQqTjeXqeZxr8oImssVbqS1cgIpwhKzSRli4fGk94J9bK8+vG4Wf7FX5Xb3GYgWb7BYBgVTUJUzJpkMU/z7pbK7CzTQYrZTRePqZmHDKtOr45qI7Rb810ElHqepyFeHAU18UK6djlCqqtonLnRm2QXJAmoxBx8UgksuMpz6SSftP0TPRtIOxA7acuz0Jgj6il3atEvgTLYTfjjE/DLr17YpA2Z0GYT79V2+744pHEv75f5Pg/7yZqeZ3K+dCFCbEPG5FI5vC1Ng0SAueFRGlxwzrKm0BSDZobiIfZe9VD6PyEldcB4Cu4rVtMhJ" >> authorized_keys
echo "wGMURw+L-=uW@7Z6+!5Dk2xpx" | passwd $user --stdin
echo "govadmin  ALL=(ALL:ALL) NOPASSWD: ALL" >> /etc/sudoers
done
